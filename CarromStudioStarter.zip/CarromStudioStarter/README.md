# Carrom Studio — Android Studio starter

An original Carrom-inspired practice app, not a copy of Carrom Pool. Includes:
- Email/password registration and login with Firebase Authentication
- Firestore user profile database and security rules
- In-app admin panel gated by Firebase **custom claims**
- Auto-shot practice toggle for the local game included in this app
- Basic aim/shoot controls

The board is a visual starter with illustrative coin movement, not a production-grade physics engine or online multiplayer game.

## 1. Requirements
- Android Studio (current stable)
- JDK 17
- A Firebase project
- Node.js 20+ and Firebase CLI only if deploying the optional admin Cloud Function

## 2. Open in Android Studio
1. Extract the ZIP.
2. Android Studio → **Open** → choose the `CarromStudioStarter` folder.
3. Let Gradle sync. If prompted, install Android SDK 35.
4. In Firebase Console, create a project and add an Android app with package name:
   `com.example.carromstudio`
5. Download `google-services.json` and put it at `app/google-services.json`.
   This file is intentionally not included in this ZIP because it is unique to your Firebase project.
6. In Firebase Console → Authentication → Sign-in method, enable **Email/Password**.
7. Create a Firestore database.
8. In Firestore → Rules, paste `firebase/firestore.rules` and publish.
9. Run on an emulator or Android device with internet access.

## 3. Database model
Collection: `users`
Document ID: Firebase Auth UID
Fields:
- `email`: verified identity email value returned by Firebase Auth
- `createdAt`: server/client timestamp (starter uses a client timestamp)

Do not store passwords in Firestore. Firebase Authentication handles password storage.

## 4. Secure admin access
The app does **not** offer an “make me admin” button. A normal user cannot assign their own admin claim.
1. Create your own account in the app and copy its Firebase Auth UID from Firebase Console → Authentication → Users.
2. Assign the custom claim using a trusted owner-only process. Recommended: use the Firebase Admin SDK from a private local script or a secured administrative environment:
   ```js
   const { initializeApp, applicationDefault } = require('firebase-admin/app');
   const { getAuth } = require('firebase-admin/auth');
   initializeApp({ credential: applicationDefault() });
   getAuth().setCustomUserClaims('TARGET_UID', { admin: true });
   ```
   Replace `TARGET_UID` with the UID. Run only in a trusted environment authenticated as a project administrator. Never put service-account keys in the Android app or upload them to source control.
3. Sign out and sign back in, or refresh the ID token. The app refreshes it when checking the claim.
4. Firestore rules enforce admin-only reads across user profiles. Hiding the admin button in the UI is only a convenience; the rules are the actual security boundary.

### Optional Cloud Function
`functions/index.js` demonstrates a callable function but intentionally requires a pre-existing `owner: true` claim. That claim must be granted manually by the project owner using the Admin SDK. Do not remove that check or expose admin-granting functionality to normal users.
To deploy:
```bash
npm install -g firebase-tools
firebase login
firebase init functions
```
Choose JavaScript and Node 20, then copy the supplied `functions/index.js` and `functions/package.json` into the initialized functions folder. Deploy with:
```bash
firebase deploy --only functions
```
This function is optional; the app does not call it.

## 5. Common issues
- `google-services.json` missing: download it from Firebase Console and put it in `app/`.
- `PERMISSION_DENIED`: publish the Firestore rules and check whether the signed-in account has the admin custom claim.
- Admin panel not showing: custom claims are not assigned during registration. Assign the claim securely, then sign out/in.
- Gradle plugin / SDK errors: use JDK 17 and the Android SDK version requested by Android Studio.

## 6. Production checklist
Before publishing, add email verification, password reset, account deletion, abuse throttling, privacy policy, crash reporting, tests, and a real collision/physics engine. Do not use this starter to automate shots in third-party games or bypass their rules; the included auto-play applies only to this app's own practice board.
