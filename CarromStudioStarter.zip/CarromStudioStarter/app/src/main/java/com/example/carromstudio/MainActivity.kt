package com.example.carromstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.math.min
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CarromApp() } }
    }
}

private val auth by lazy { FirebaseAuth.getInstance() }
private val db by lazy { FirebaseFirestore.getInstance() }

@Composable
private fun CarromApp() {
    var user by remember { mutableStateOf(auth.currentUser) }
    var isAdmin by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun refreshAdmin() {
        val current = auth.currentUser
        if (current == null) { isAdmin = false; return }
        scope.launch {
            isAdmin = try {
                // Custom claims are assigned only by trusted Admin SDK code.
                current.getIdToken(true).await().claims["admin"] == true
            } catch (_: Exception) { false }
        }
    }

    LaunchedEffect(user?.uid) { refreshAdmin() }

    if (user == null) {
        AuthScreen(
            busy = busy,
            message = message,
            onLogin = { email, password ->
                scope.launch {
                    busy = true; message = ""
                    try {
                        auth.signInWithEmailAndPassword(email.trim(), password).await()
                        user = auth.currentUser
                        message = "Signed in."
                    } catch (e: Exception) { message = e.message ?: "Login failed." }
                    busy = false
                }
            },
            onRegister = { email, password ->
                scope.launch {
                    busy = true; message = ""
                    try {
                        val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
                        val uid = result.user?.uid ?: error("Account creation failed")
                        db.collection("users").document(uid).set(
                            mapOf("email" to email.trim(), "createdAt" to com.google.firebase.Timestamp.now())
                        ).await()
                        user = auth.currentUser
                        message = "Account created."
                    } catch (e: Exception) { message = e.message ?: "Registration failed." }
                    busy = false
                }
            }
        )
    } else {
        var showAdmin by remember { mutableStateOf(false) }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("CARROM STUDIO", fontSize = 26.sp, color = Color(0xFF7A3E16))
            Text("Signed in as ${user?.email ?: "player"}")
            Spacer(Modifier.height(12.dp))
            CarromBoard()
            Spacer(Modifier.height(12.dp))
            Text("Original offline practice board — auto-shot is for this app's own game.")
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showAdmin = !showAdmin }, enabled = isAdmin) {
                    Text(if (showAdmin) "Hide admin" else "Admin panel")
                }
                OutlinedButton(onClick = {
                    auth.signOut(); user = null; isAdmin = false; showAdmin = false
                    message = "Signed out."
                }) { Text("Sign out") }
            }
            if (!isAdmin) Text("Admin tools are available only to accounts granted the server-side admin claim.", fontSize = 12.sp)
            if (showAdmin && isAdmin) AdminPanel()
            if (message.isNotBlank()) Text(message, color = Color(0xFF386641))
        }
    }
}

@Composable
private fun AuthScreen(
    busy: Boolean, message: String,
    onLogin: (String, String) -> Unit,
    onRegister: (String, String) -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("CARROM STUDIO", fontSize = 28.sp, color = Color(0xFF7A3E16))
        Text("Sign in or create an account")
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text("Password (6+ characters)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = { onLogin(email, password) }) { Text("Login") }
            OutlinedButton(enabled = !busy, onClick = { onRegister(email, password) }) { Text("Register") }
        }
        if (busy) CircularProgressIndicator()
        if (message.isNotBlank()) Text(message)
    }
}

@Composable
private fun CarromBoard() {
    var autoShot by remember { mutableStateOf(false) }
    var shotCount by remember { mutableIntStateOf(0) }
    var strikerX by remember { mutableFloatStateOf(0.5f) }
    var strikerY by remember { mutableFloatStateOf(0.78f) }
    var coinOffsets by remember {
        mutableStateOf(listOf(
            Offset(.50f, .50f), Offset(.46f, .50f), Offset(.54f, .50f),
            Offset(.50f, .46f), Offset(.50f, .54f), Offset(.43f, .46f),
            Offset(.57f, .54f)
        ))
    }
    LaunchedEffect(autoShot) {
        while (autoShot) {
            kotlinx.coroutines.delay(850)
            coinOffsets = coinOffsets.map { p ->
                if (Random.nextFloat() < .38f) Offset(
                    (p.x + Random.nextFloat() * .16f - .08f).coerceIn(.18f, .82f),
                    (p.y + Random.nextFloat() * .16f - .08f).coerceIn(.18f, .82f)
                ) else p
            }
            strikerX = Random.nextFloat() * .48f + .26f
            shotCount++
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.fillMaxWidth().aspectRatio(1f).padding(4.dp)) {
            val side = min(size.width, size.height)
            val board = Size(side, side)
            drawRect(Color(0xFFDCA96A), size = board)
            drawRect(Color(0xFF6F3517), topLeft = Offset(0f,0f), size = board, style = androidx.compose.ui.graphics.drawscope.Stroke(width = side * .035f))
            drawCircle(Color(0xFF6F3517), radius = side*.27f, center = Offset(side*.5f, side*.5f), style = androidx.compose.ui.graphics.drawscope.Stroke(width=side*.008f))
            val pockets = listOf(Offset(.08f,.08f),Offset(.92f,.08f),Offset(.08f,.92f),Offset(.92f,.92f))
            pockets.forEach { drawCircle(Color.Black, side*.045f, Offset(side*it.x,side*it.y)) }
            coinOffsets.forEachIndexed { i, p ->
                drawCircle(if (i == 0) Color(0xFFB7192E) else if (i % 2 == 0) Color(0xFF292929) else Color(0xFFF5E6C8),
                    side*.022f, Offset(side*p.x, side*p.y))
            }
            drawCircle(Color(0xFF355C9A), side*.035f, Offset(side*strikerX, side*strikerY))
            drawCircle(Color.White, side*.008f, Offset(side*strikerX, side*strikerY))
        }
        Text("Shots: $shotCount")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Auto-play practice")
            Switch(checked = autoShot, onCheckedChange = { autoShot = it })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { strikerX = (strikerX - .06f).coerceAtLeast(.2f); shotCount++ }) { Text("← Aim") }
            Button(onClick = {
                coinOffsets = coinOffsets.map { p -> Offset((p.x + Random.nextFloat()*.12f-.06f).coerceIn(.15f,.85f), (p.y + Random.nextFloat()*.12f-.06f).coerceIn(.15f,.85f)) }
                shotCount++
            }) { Text("Shoot") }
            OutlinedButton(onClick = { strikerX = (strikerX + .06f).coerceAtMost(.8f); shotCount++ }) { Text("Aim →") }
        }
        Text("Demo physics only; coins move illustratively, not with a full collision engine.", fontSize = 11.sp)
    }
}

@Composable
private fun AdminPanel() {
    var status by remember { mutableStateOf("Admin access verified by Firebase custom claim.") }
    var userCount by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Card(Modifier.fillMaxWidth().padding(top = 12.dp), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Admin panel", fontSize = 20.sp)
            Text("This starter keeps admin access separate from normal user registration.")
            Button(onClick = {
                scope.launch {
                    status = try {
                        val snap = db.collection("users").get().await()
                        userCount = snap.size().toString()
                        "User list access succeeded."
                    } catch (e: Exception) { "Request denied or failed: ${e.message}" }
                }
            }) { Text("Count registered users") }
            userCount?.let { Text("Registered profiles: $it") }
            Text(status, fontSize = 12.sp)
        }
    }
}
