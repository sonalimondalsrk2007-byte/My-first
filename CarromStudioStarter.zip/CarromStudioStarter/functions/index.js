const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");

initializeApp();

// Deploy this function only from a trusted project owner environment.
// Never expose an endpoint that lets users grant themselves admin.
exports.grantAdminClaim = onCall(async (request) => {
  if (!request.auth || request.auth.token.owner !== true) {
    throw new HttpsError("permission-denied", "Only the project owner can grant admin access.");
  }
  const uid = String(request.data?.uid || "");
  if (!uid) throw new HttpsError("invalid-argument", "Provide a target uid.");
  await getAuth().setCustomUserClaims(uid, { admin: true });
  return { ok: true, uid };
});
